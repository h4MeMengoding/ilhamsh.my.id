import BlogListNew from './components/BlogListNew';

export default BlogListNew;
