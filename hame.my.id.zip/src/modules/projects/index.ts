import Projects from './components/Projects';

export default Projects;
