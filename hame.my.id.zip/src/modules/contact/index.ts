import Contact from './components/Contact';

export default Contact;
