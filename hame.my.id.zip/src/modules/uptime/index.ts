import Uptime from './components/Uptime';

export default Uptime;
