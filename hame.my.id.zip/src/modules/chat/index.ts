import Chat from './components/Chat';

export default Chat;
