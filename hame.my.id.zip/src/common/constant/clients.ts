export const CLIENT_IMAGES = [
  '/images/clients/sirka.png',
  '/images/clients/mitech.png',
  '/images/clients/areakampus.png',
  '/images/clients/unsyiah.png',
  '/images/clients/telkom.png',
  '/images/clients/travelkuala.png',
  '/images/clients/daneen.png',
  '/images/clients/phe.png',
  '/images/clients/fixature.png',
  '/images/clients/negeriantara.png',
];
